//
//  ViewController.swift
//  Siri
//
//  Created by Sahand Edrisian on 7/14/16.
//  Copyright © 2016 Sahand Edrisian. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
	
	
	@IBOutlet weak var textView: UITextView!
	@IBOutlet weak var microphoneButton: UIButton!
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
	}

	@IBAction func microphoneTapped(_ sender: AnyObject) {

	}

}

